class Game:
    pass
